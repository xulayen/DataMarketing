﻿var _hmt = _hmt || [];
$(function () {

	var hm = document.createElement("script");
	hm.src = "//hm.baidu.com/hm.js?7aa10563c436f71ad97e19c5625b6aa6";
	var s = document.getElementsByTagName("script")[0]; 
	s.parentNode.insertBefore(hm, s);

   //得到焦点
    var Request = new Object(); 
	Request = GetRequest(); 
	c=Request["c"];
	openid=Request["openid"];

	if(c==null || c=="")
	{
		c="0";
	}
	if(openid==null||openid=="")
	{
		openid="";
	}
    var url = "Ashx/WOMHandler.ashx?m=checkip&cid=" + c;
    $.ajax({
        type: 'POST',
        url: url,
        dataType: 'text',
        timeout: 600000,
        success: function (data) {
        //alert(data);
 
        },
        error: function(data,status){
        	//alert(status);
        }
    });

    if(c=="1")
    {
    	//1是微信，跳线下
    	window.location.href="offlineact.html?c=1&openid="+openid;
    }
    else
    {
    	//其他跳线上
    	window.location.href="onlineact.html?c=" + c+"&openid="+openid;
    }

});

var c="";

function GetRequest() { 
	var url = location.search; //获取url中"?"符后的字串 
	var theRequest = new Object(); 
	var returnVal = "传过来的参数";
	if (url.indexOf("?") != -1) { 
		var str = url.substr(1); 
		strs = str.split("&"); 
		for(var i = 0; i < strs.length; i ++) { 
			theRequest[strs[i].split("=")[0]]=unescape(strs[i].split("=")[1]); 
			//returnVal = returnVal + "--" + strs[i].split("=")[0] + ":"+unescape(strs[i].split("=")[1]);
		} 
	} 
	return theRequest; 
} 





