﻿
$(function () {
	//先初始化省份的选项
	initSelection('Prov');

	//获得过来的预约号
	var Request = new Object(); 
	Request = GetRequest(); 
	resGuid = Request["resGuid"];
	//alert(resGuid);

});

var statVal = "";
var cityVal = "";
var shopVal = "";
var isClickClean = false;
var resGuid = "";


function GetRequest() { 
	var url = location.search; //获取url中"?"符后的字串 
	var theRequest = new Object(); 
	var returnVal = "传过来的参数";
	if (url.indexOf("?") != -1) { 
		var str = url.substr(1); 
		strs = str.split("&"); 
		for(var i = 0; i < strs.length; i ++) { 
			theRequest[strs[i].split("=")[0]]=unescape(strs[i].split("=")[1]); 
			//returnVal = returnVal + "--" + strs[i].split("=")[0] + ":"+unescape(strs[i].split("=")[1]);
		} 
	} 
	return theRequest; 
} 

function saveSelect()
{
	var elemInput;
	if(statVal == "")
	{
		elemInput = $('#state').parent('li').children('input');
		elemInput.val("选择省份");
		elemInput.removeClass("-dark -clean -clean2");
		elemInput.addClass("-alert");
		setTimeout("changeCss(1)", 300);
		return;
	}
	else if(cityVal == "")
	{
		elemInput = $('#city').parent('li').children('input');
		elemInput.val("选择城市");
		elemInput.removeClass("-dark -clean -clean2");
		elemInput.addClass("-alert");
		setTimeout("changeCss(2)", 300);
		return;
	}
	else if(shopVal == "")
	{
		elemInput = $('#shop').parent('li').children('input');
		elemInput.val("选择门店");
		elemInput.removeClass("-dark -clean -clean2");
		elemInput.addClass("-alert");
		setTimeout("changeCss(3)", 300);
		return;
	}

	var url = "Ashx/WOMHandler.ashx?m=saveSelect&resGuid=" + resGuid + "&storeid="+shopVal;


	$.ajax({
    type: 'POST',
    url: url,
    dataType: 'text',
    timeout: 600000,
    success: function (data) {
    	//alert(data);
    	if(data=="1")
    	{
    		$('#popDiv3,#maskLayer').show();
    	}
    },
    error: function(data,status){
    	
    }
    });

	
}
function changeCss(place)
{
	var elemInput;
	if(place=="1")
	{
		elemInput = $('#state').parent('li').children('input');
		elemInput.val("选择省份");
	}
	else if(place=="2")
	{
		elemInput = $('#city').parent('li').children('input');
		elemInput.val("选择城市");
	}
	else if(place=="3")
	{
		elemInput = $('#shop').parent('li').children('input');
		elemInput.val("选择城市");
	}
	elemInput.removeClass("-dark -clean -clean2 -alert");
	elemInput.addClass("-clean2");
	
	//elem.removeClass("-dark -clean -clean2 -alert");
	//elem.addClass("-clean");
}
function doBeforePick(select){
	//在弹出选项框之前，检查选项是否为空，如果为空就不弹出
	if(isClickClean)
	{
		isClickClean = false;
		return false;
	}
	//判断上级内容是否为空，为空就返回不弹出选项框
	if(select.id == "city" && statVal == "")
	{
		return false;
	}
	else if(select.id == "shop" && (cityVal == "" || statVal ==""))
	{
		return false;
	}

	//检查选项，如果为空就不弹出
	var options = select.options;
	if(options.length<=0)
	{
		return false;
	}

	//alert(select.id);
	//如果已经有值，就不清除样式了
	if(select.id == "state" && statVal == "")
	{
		select.parentElement.querySelector('.pk-input').className='pk-input -dark';
	}
	else if(select.id == "city" && cityVal == "")
	{
		select.parentElement.querySelector('.pk-input').className='pk-input -dark';
	}
	else if(select.id == "shop" && shopVal == "")
	{
		select.parentElement.querySelector('.pk-input').className='pk-input -dark';
	}

	return true;

}

function doAfterPicked(select,val){
	//选中选项后，设置样式
	if(select.id=="state" && val !="")
	{
		statVal = val;
		//根据选择的省份值，初始化城市列表
		initSelection("City");
		select.parentElement.querySelector('.pk-input').className='pk-input -clean';
		//清空城市和门店信息
		cleanInput(false,true,true,false);
	}
	else if(select.id=="city" && val !="")
	{
		cityVal = val;
		//根据选择的城市值，初始化门店列表
		initSelection("Shop");
		select.parentElement.querySelector('.pk-input').className='pk-input -clean';
		//清空门店信息
		cleanInput(false,false,true,false);
	}
	else if(select.id=="shop" && val !="")
	{
		//shopVal = val;
		var shopInfo ;
		if($('#shop').val()!=null && $('#shop').val()!="")
		{
			shopInfo = $('#shop').val().split("@@");
			//根据选择的门店，显示门店详细信息
			if(shopInfo.length==3)
			{
				var info="<dl><dd>门店编号："+shopInfo[1]+"</dd><dd>门店名称："+shopInfo[0]+"</dd><dd>门店地址："+shopInfo[2]+"</dd></dl>";
				$('#showlist').html(info);
				$('#showlist').css('display','block');
				shopVal = shopInfo[1];
			}
		}
		select.parentElement.querySelector('.pk-input').className='pk-input -clean';
	}

}


function initSelection(showwhat){
	//先清除选择区的内容

	//如果是按了清除按钮，就返回，不继续处理

	var showThing = "";
	var url = "Ashx/WOMHandler.ashx?m=";

	if(showwhat=="Prov"){
		//alert('显示prov');
		url = url + "getProv";

		//alert(url);
		$.ajax({
        type: 'POST',
        url: url,
        dataType: 'text',
        timeout: 600000,
        success: function (data) {
        	//alert(data);
        	var list=data.split("|");
        	for(var i=0;i<list.length;i++)
        	{
        		showThing = showThing + "<option>"+checkLengh(list[i],10)+"</option>";
        	}
			$('#state').html(showThing);
        },
        error: function(data,status){
        	
        }
    });
	}
	else if(showwhat == "City"){

		url = url + "getCity&stat="+statVal;
		//alert(url);
		$.ajax({
        type: 'POST',
        url: url,
        dataType: 'text',
        timeout: 600000,
        success: function (data) {
        	//alert(data);
        	var list=data.split("|");
        	for(var i=0;i<list.length;i++)
        	{
        		showThing = showThing + "<option>"+checkLengh(list[i],10)+"</option>";
        	}
			$('#city').html(showThing);

        },
        error: function(data,status){
        }
    });
	}
	else if(showwhat == "Shop"){
		//alert('显示Shop');
		url = url + "getShop&stat="+statVal+"&city="+cityVal;

		//alert(url);
		$.ajax({
        type: 'POST',
        url: url,
        dataType: 'text',
        timeout: 600000,
        success: function (data) {
        	//alert(data);
        	var list=data.split("|");
        	var shopinfo;
        	for(var i=0;i<list.length;i++)
        	{
        		shopinfo=list[i].split("@@");
        		showThing = showThing + "<option value='"+list[i]+"'>"+checkLengh(shopinfo[0],10)+"</option>";
        	}
			$('#shop').html(showThing);


            //alert("访问者的IP地址：" + data);
        },
        error: function(data,status){
        }
    });
	}
}


function cleanInput(cleanProv,cleanCity,cleanShop,isBlock)
{
	
	isClickClean = isBlock;
	if(cleanProv)
	{
		statVal = "";
		var statInput = $('#state').parent('li').children('input');
		statInput.val("选择省份");
		statInput.removeClass("-dark -clean -clean2");
		statInput.addClass("-clean2");
		//var statSelect = $('#state');
		//statSelect.parentElement.querySelector('.pk-input').value="选择省份";
		//statSelect.parentElement.querySelector('.pk-input').className='pk-input -clean2';
	}
	if(cleanCity)
	{
		cityVal = "";
		var cityInput = $('#city').parent('li').children('input');
		cityInput.val("选择城市");
		cityInput.removeClass("-dark -clean -clean2");
		cityInput.addClass("-clean2");

	}
	if(cleanShop)
	{
		shopVal = "";
		var shopInput = $('#shop').parent('li').children('input');
		shopInput.val("选择门店");
		shopInput.removeClass("-dark -clean -clean2");
		shopInput.addClass("-clean2");
		$('#showlist').css('display','none');
	}
}

function checkLengh(str,len)
{
	var cd=str.length;
	if(cd>len){
		return str.substring(0,len-1)+"…";
	}
	else
	{
		return str;
	}
}





