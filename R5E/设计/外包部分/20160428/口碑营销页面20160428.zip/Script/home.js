﻿
$(function () {

	var Request = new Object(); 
	Request = GetRequest(); 
	c=Request["c"];
	openid = Request["openid"];
	if(openid==null || openid=="")
	{
		openid="";
	}
});



var statVal = "";
var cityVal = "";
var shopVal = "";
var openId = "";
var isClickClean = false;
var nowTop = 0;
var isImgPop = false;

function GetRequest() { 
	var url = location.search; //获取url中"?"符后的字串 
	var theRequest = new Object(); 
	var returnVal = "传过来的参数";
	if (url.indexOf("?") != -1) { 
		var str = url.substr(1); 
		strs = str.split("&"); 
		for(var i = 0; i < strs.length; i ++) { 
			theRequest[strs[i].split("=")[0]]=unescape(strs[i].split("=")[1]); 
			//returnVal = returnVal + "--" + strs[i].split("=")[0] + ":"+unescape(strs[i].split("=")[1]);
		} 
	} 
	return theRequest; 
} 
function showPop2()
{
	//alert("总高："+document.body.offsetHeight);
	//alert("相对高："+document.body.scrollTop);
	nowTop = document.body.scrollTop;
	$('#home').css('top',-1*document.body.scrollTop);
	$('#home').css('position','fixed');
	$('#maskLayer').css('position','fixed');


	$('#popDiv2,#maskLayer').show();
}

function showPop1()
{
	//alert(document.body.offsetHeight);

	//alert("相对高："+document.body.scrollTop);
	nowTop = document.body.scrollTop;
	$('#home').css('top',-1*document.body.scrollTop);
	$('#home').css('position','fixed');
	$('#maskLayer').css('position','fixed');
	$('#popDiv1,#maskLayer').show();
}

function showPop3()
{
	isImgPop=!isImgPop;

	$('#popImg,#maskLayer').toggle();
}
function hidePopOffline()
{
	$('#home').css('top','0');
	$('#home').css('position','relative');
	$('#maskLayer').css('position','absolute');
	$('#popDiv1,#popDiv2,#maskLayer').hide();
	$(window).scrollTop(nowTop);
}
function hidePopOnline()
{
	if(!isImgPop)
	{
		$('#home').css('top','0');
		$('#home').css('position','relative');
		$('#maskLayer').css('position','absolute');
		$('#popDiv1,#popDiv2,#maskLayer').hide();
		$(window).scrollTop(nowTop);
	}
	else
	{
		isImgPop=false;
		$('#popImg,#maskLayer').toggle();
	}
}
function toOther()
{
	window.location.href="http://dm.zhsh.co/r/server/UserAuth.ashx?type=1&userOpenid="+openid;
}

function checkPhone(){
	var phone = $('#phoneNum').val();
	if(phone==null || phone =="" || isNaN(phone) ||phone.length!=11|| (phone.substr(0,2)!="13"&& phone.substr(0,2)!="15"&&phone.substr(0,2)!="17"&&phone.substr(0,2)!="18"))
	{
		$('#phoneNum').val("请填写正确的手机号");
	}
	else
	{
		var url = "Ashx/WOMHandler.ashx?m=checkPhone&phoneNum=" + phone + "&cid=" + c + "&openid=" + openid;
		$.ajax({
        type: 'POST',
        url: url,
        dataType: 'text',
        timeout: 600000,
        success: function (data) {
        	//1表示未注册过，可以跳转
        	if(data.substr(0,1)=="1"){
        		window.location.href="Success.html?resGuid=" + data.substr(2,data.lenght);
        	}
        	//2表示已注册过
        	else if(data.substr(0,1)=="2"){
        		$('#phoneNum').val("每个号码仅能领取一次");
        	}
        },
        error: function(data,status){
        	
        }
    });
	}
}


function showSelection(showwhat){
	//先清除选择区的内容
	$('#showlist').html("");

	$('#showlist').css('display','block');
	$('#shopinfo').css('display','none');

	//如果是按了清除按钮，就返回，不继续处理
	if(isClickClean)
	{
		isClickClean = false;
		return;
	}
	var showThing = "";
	var url = "Ashx/WOMHandler.ashx?m=";

	if(showwhat=="Prov"){
		//alert('显示prov');
		url = url + "getProv";

		//如果已经有值，就不清除样式了
		if(statVal == "")
		{
			$('#state').removeClass("pk-input -clean2");
			$('#state').addClass("pk-input -dark");
		}
		//alert(url);
		$.ajax({
        type: 'POST',
        url: url,
        dataType: 'text',
        timeout: 600000,
        success: function (data) {
        	//alert(data);
        	var list=data.split("|");
        	for(var i=0;i<list.length;i++)
        	{
        		showThing = showThing + "<li><span onclick=\"setProv('"+list[i]+"',this);\" >"+checkLengh(list[i],4)+"</span></li>";
        	}
			$('#showlist').html(showThing);

			//清除城市和门店记录
			cleanInput(false,true,true,false);
            //alert("访问者的IP地址：" + data);
        },
        error: function(data,status){
        	showThing = showThing + "<li style='width:100%'><span >网络传输异常，请稍后再试</span></li>";
        	$('#showlist').html(showThing);
        }
    });
	}
	else if(showwhat == "City"){
		//如果省份未选择，则直接返回，不处理
		if(statVal == "")
		{
			return false;
		}
		url = url + "getCity&stat="+statVal;

		//如果已经有值，就不清除样式了
		if(cityVal == "")
		{
			$('#city').removeClass("pk-input -clean2");
			$('#city').addClass("pk-input -dark");
		}
		//alert(url);
		$.ajax({
        type: 'POST',
        url: url,
        dataType: 'text',
        timeout: 600000,
        success: function (data) {
        	//alert(data);
        	var list=data.split("|");
        	for(var i=0;i<list.length;i++)
        	{
        		showThing = showThing + "<li><span onclick=\"setCity('"+list[i]+"',this);\" >"+checkLengh(list[i],4)+"</span></li>";
        	}
			$('#showlist').html(showThing);

			//清除门店记录
			cleanInput(false,false,true,false);
            //alert("访问者的IP地址：" + data);
        },
        error: function(data,status){
        	showThing = showThing + "<li style='width:100%'><span >网络传输异常，请稍后再试</span></li>";
        	$('#showlist').html(showThing);
        }
    });
	}
	else if(showwhat == "Shop"){
		//alert('显示Shop');
		//如果城市未选择，则直接返回，不处理
		if(cityVal == "" ||  statVal == "")
		{
			return false;
		}
		url = url + "getShop&stat="+statVal+"&city="+cityVal;

		//如果已经有值，就不清除样式了
		if(shopVal == "")
		{
			$('#shop').removeClass("pk-input -clean2");
			$('#shop').addClass("pk-input -dark");
		}
		//alert(url);
		$.ajax({
        type: 'POST',
        url: url,
        dataType: 'text',
        timeout: 600000,
        success: function (data) {
        	//alert(data);
        	var list=data.split("|");
        	var shopinfo;
        	for(var i=0;i<list.length;i++)
        	{
        		shopinfo=list[i].split("@@");
        		showThing = showThing + "<li style='width:100%'><span onclick=\"setShop('"+shopinfo[0]+"','"+shopinfo[1]+"','"+shopinfo[2]+"');\" >"+checkLengh(shopinfo[0],15)+"</span></li>";
        	}
			$('#showlist').html(showThing);


            //alert("访问者的IP地址：" + data);
        },
        error: function(data,status){
        	showThing = showThing + "<li style='width:100%'><span >网络传输异常，请稍后再试</span></li>";
        	$('#showlist').html(showThing);
        }
    });
	}
}
function setChooseClass(e)
{
	$(e).parent().parent().children().each(function(){
		$(this).children('span').removeClass('choose');
	});
	$(e).addClass('choose');
}
function setProv(val,e)
{
	$('#state').removeClass("pk-input -dark");
	$('#state').addClass("pk-input -clean");
	$('#state').html(val+"<i onclick='cleanInput(true,true,true,true);' class='del'></i>");
	statVal = val;
	setChooseClass(e);
}
function setCity(val,e)
{
	$('#city').removeClass("pk-input -dark");
	$('#city').addClass("pk-input -clean");
	$('#city').html(val+"<i onclick='cleanInput(false,true,true,true);' class='del\'></i>");
	cityVal = val;
	setChooseClass(e);
}
function setShop(name,id,addr)
{
	$('#shop').removeClass("pk-input -dark");
	$('#shop').addClass("pk-input -clean");
	$('#shop').html(checkLengh(name,10)+"<i onclick='cleanInput(false,false,true,true);' class='del\'></i>");

	var info="<dl><dd>门店编号："+id+"</dd><dd>门店名称："+name+"</dd><dd>门店地址："+addr+"</dd></dl>";
	$('#showlist').css('display','none');
	$('#shopinfo').html(info);
	$('#shopinfo').css('display','block');
	shopVal = name;
	$('#plsSel').html("");
}

function cleanInput(cleanProv,cleanCity,cleanShop,isBlock)
{
	isClickClean = isBlock;
	if(cleanProv)
	{
		statVal = "";
		$('#state').html("选择省份");
		$('#state').removeClass("-dark -clean -clean2");
		$('#state').addClass("-clean2");
	}
	if(cleanCity)
	{
		cityVal = "";
		$('#city').html("选择城市");
		$('#city').removeClass("-dark -clean -clean2");
		$('#city').addClass("-clean2");
	}
	if(cleanShop)
	{
		shopVal = "";
		$('#plsSel').html("请选择");
		$('#shop').html("选择门店");
		$('#shop').removeClass("-dark -clean -clean2");
		$('#shop').addClass("-clean2");
		$('#shopinfo').css('display','none');
	}
}

function checkLengh(str,len)
{
	var cd=str.length;
	if(cd>len){
		return str.substring(0,len-1)+"…";
	}
	else
	{
		return str;
	}
}





