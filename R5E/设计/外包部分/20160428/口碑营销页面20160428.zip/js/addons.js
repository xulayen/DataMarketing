$(function() {
	
		//页面不足一屏，铺满一屏
	$('.layout').css('min-height',$(window).height());

$('.faq-tc').click(function(){
			$(this).toggleClass("active");
		});
	$('#maskLayer').click(function(){
			$('.faq-tc').removeClass("active");
		});	
		/*$('.dialog_blank').height($('body').height());
		$('#btn1').click(function(){
			$('.dialog_blank').show();
			$('.load-dialog').show();
		});
		$('.dialog_close, .dialog_goback').click(function(){
			$('.dialog_blank').hide();
			$(this).parents('.dialog').hide();
		});*/
		
})
